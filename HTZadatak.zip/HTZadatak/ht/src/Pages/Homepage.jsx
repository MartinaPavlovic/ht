import Header from '../Components/Header';
import '../Pages/Homepage.css';
import Slider from '../Components/Slider';
import Button from '../Components/Button';
import Box from '../Components/Box';
import Footer from '../Components/Footer';

function Homepage() {
    return (
        <>
            <Header />
            <Slider />
            <Box />
            <Button /> 
            <Footer />           
        </>
    )
}

export default Homepage;