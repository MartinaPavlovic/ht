import '../Pages/Packagepage.css';
import Header2 from '../Components/Header2';
import Table from '../Components/Table';


function Packagepage() {
    return (
        <>   
            <Table />
        </>
    );
}

export default Packagepage;