export const SliderData = [
    {
        image: "https://www.t.ht.hr/webresources/tht/img/video-home-poster.jpg",    
        heading: "Hrvatski telekom",
        desc: "Hrvatski Telekom - vaš najbolji prijatelj u svijetu tehnologije. Uvijek vam donosi najnovije uređaje, najisplativije tarife i vrhunske usluge.",
    },
    {
        image: "https://www.telekom.hu/static-tr/sw/pic/w/7/markakuldetesunk-hero/markakuldetesunk-hero.png",
        heading: "Dostava",
        desc: "Uživajte u naručivanju najnovijih mobilnih uređaja svojih omiljenih brendova iz udobnosti vlastitog doma. Naša dostava je brza, sigurna i pouzdana.",
    }
]