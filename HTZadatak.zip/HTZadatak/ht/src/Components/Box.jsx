import '../Pages/Homepage.css';

function Box() {
    return (
        <div className="box-container">
            <figure>
                <img src="dostava.png" />
                <figcaption className='fig'>Sigurna dostava.</figcaption>
            </figure>
            <figure>
                <img src="sat.png" />
                <figcaption className='fig'>Bez dugo čekanja.</figcaption>
            </figure>
            <figure>
                <img src="loc2.png" />
                <figcaption className='fig2'>Dolazak na Vašu adresu.</figcaption>
            </figure>
            <figure>
                <img src="hrv.png" />
                <figcaption className='fig2'>Povezuje cijelu Hrvatsku.</figcaption>
            </figure>
        </div>
    );
}

export default Box;
