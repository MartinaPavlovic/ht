import '../Pages/Homepage.css';
import { FaInstagram, FaFacebook, FaTiktok, FaTwitter } from "react-icons/fa";

function Footer() {
    return (
        <div className='footer'>
            <h1>Pratite nas na društvenim mrežama!</h1>
            <FaInstagram className='social-icon' />
            <FaFacebook className='social-icon' />
            <FaTiktok className='social-icon' />
            <FaTwitter className='social-icon' />
        </div>
    );
}

export default Footer;
