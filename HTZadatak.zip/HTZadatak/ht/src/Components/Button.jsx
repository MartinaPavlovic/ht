import React from 'react';
import '../Pages/Homepage.css'

function Button() {
    const handleButtonClick = () => {
        window.location.href = '/packages';
    };

    return (
        <div>
            <p className='desc'>Sada je praćenje i upravljanje pošiljkama jednostavnije nego ikad. Sve to možete obaviti na jednom mjestu.</p>
            <button className="newBtn" onClick={handleButtonClick}>
                <div className='text'>Pogledaj pošiljke!</div>
            </button>
        </div>
    );
}

export default Button;
