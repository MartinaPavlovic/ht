import '../Pages/Homepage.css'

function Header() {
    return (
        <div className="header">  
            <h1 className='title'>Dobrodošli u Hrvatski telekom! </h1>
        </div>
    );
}

export default Header;