import '../Pages/Packagepage.css';
import { useState, useEffect } from 'react';
import { FaEdit } from "react-icons/fa";
import { RiDeleteBin6Line } from "react-icons/ri";

function Table() {
    const [currentPage, setCurrentPage] = useState(1);
    const packagesPerPage = 10;
    const [idKorisnika, setIdKorisnika] = useState('');
    const [status, setStatus] = useState('');
    const [idNarudzbe, setIdNarudzbe] = useState('');
    const [idPosiljke, setIdPosiljke] = useState('');
    const [currentPackages, setCurrentPackages] = useState([]);
    const [filteredPackages, setFilteredPackages] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [newPackage, setNewPackage] = useState({
        datumDostave: '',
        vrijemeDostave: '',
        adresaDostave: '',
        gradDostave:'',
        status: ''
    });

    const [editPackage, setEditPackage] = useState(null);
    const handleEditPackage = (Package) => {
        setEditPackage(Package);
    };

    useEffect(() => {
        const savedPackages = JSON.parse(localStorage.getItem('packages')) || [];
        if (savedPackages.length > 0) {
            setCurrentPackages(savedPackages);
            setFilteredPackages(savedPackages);
        } else {
            const mockPackages = [
                { idPosiljke: 1, idKorisnika: 101, idNarudzbe: 198, datumDostave: '2023-06-01', vrijemeDostave: '12:00', status: 'na putu', adresaDostave: 'Unska 3', gradDostave: 'Zagreb' },
                { idPosiljke: 2, idKorisnika: 102, idNarudzbe: 199, datumDostave: '2023-06-02', vrijemeDostave: '14:30', status: 'dostavljeno', adresaDostave: 'Ilica 10', gradDostave: 'Zagreb' },
                { idPosiljke: 3, idKorisnika: 103, idNarudzbe: 200, datumDostave: '2023-06-03', vrijemeDostave: '09:45', status: 'u pripremi', adresaDostave: 'Savska 15', gradDostave: 'Zagreb' },
                { idPosiljke: 4, idKorisnika: 104, idNarudzbe: 201, datumDostave: '2023-06-04', vrijemeDostave: '11:15', status: 'odgođeno', adresaDostave: 'Trg Bana Jelačića 1', gradDostave: 'Zagreb' },
                { idPosiljke: 5, idKorisnika: 105, idNarudzbe: 202, datumDostave: '2023-06-05', vrijemeDostave: '10:30', status: 'na putu', adresaDostave: 'Zagrebačka 5', gradDostave: 'Zagreb' },
                { idPosiljke: 6, idKorisnika: 106, idNarudzbe: 203, datumDostave: '2023-06-06', vrijemeDostave: '08:00', status: 'dostavljeno', adresaDostave: 'Heinzelova 55', gradDostave: 'Zagreb' },
                { idPosiljke: 7, idKorisnika: 107, idNarudzbe: 204, datumDostave: '2023-06-07', vrijemeDostave: '13:00', status: 'u pripremi', adresaDostave: 'Maksimirska 22', gradDostave: 'Zagreb' },
                { idPosiljke: 8, idKorisnika: 108, idNarudzbe: 205, datumDostave: '2023-06-08', vrijemeDostave: '15:00', status: 'odgođeno', adresaDostave: 'Petrova 12', gradDostave: 'Zagreb' },
                { idPosiljke: 9, idKorisnika: 109, idNarudzbe: 206, datumDostave: '2023-06-09', vrijemeDostave: '09:00', status: 'na putu', adresaDostave: 'Palmotićeva 7', gradDostave: 'Zagreb' },
                { idPosiljke: 10, idKorisnika: 110, idNarudzbe: 207, datumDostave: '2023-06-10', vrijemeDostave: '11:30', status: 'dostavljeno', adresaDostave: 'Vlaška 45', gradDostave: 'Zagreb' },
                { idPosiljke: 11, idKorisnika: 111, idNarudzbe: 208, datumDostave: '2023-06-11', vrijemeDostave: '12:45', status: 'u pripremi', adresaDostave: 'Kaptol 1', gradDostave: 'Zagreb' },
                { idPosiljke: 12, idKorisnika: 112, idNarudzbe: 209, datumDostave: '2023-06-12', vrijemeDostave: '10:15', status: 'odgođeno', adresaDostave: 'Frankopanska 9', gradDostave: 'Zagreb' },
                { idPosiljke: 13, idKorisnika: 113, idNarudzbe: 210, datumDostave: '2023-06-13', vrijemeDostave: '14:45', status: 'na putu', adresaDostave: 'Dubrovnikska 3', gradDostave: 'Zagreb' }
            ];

            setCurrentPackages(mockPackages);
            setFilteredPackages(mockPackages);
            localStorage.setItem('packages', JSON.stringify(mockPackages));
        }

        document.body.classList.add('package-page');

        return () => {
            document.body.classList.remove('package-page');
        };
    }, []);

    const handleSearch = () => {
        const filtered = currentPackages.filter((item) => {
            return (
                (status ? item.status.toLowerCase().includes(status.toLowerCase()) : true) &&
                (idNarudzbe ? item.idNarudzbe.toString().includes(idNarudzbe) : true) &&
                (idKorisnika ? item.idKorisnika.toString().includes(idKorisnika) : true) &&
                (idPosiljke ? item.idPosiljke.toString().includes(idPosiljke) : true)
            );
        });
        setFilteredPackages(filtered);
    };

    const generateId = (prefix) => {
        return prefix + Math.floor(Math.random() * 1000);
    };

    const handleAddPackage = (e) => {
        e.preventDefault();
        const newIdPosiljke = currentPackages.length > 0 ? currentPackages[currentPackages.length - 1].idPosiljke + 1 : 1;
        const newIdKorisnika = generateId(100);
        const newIdNarudzbe = generateId(200);
        const updatedPackages = [...currentPackages, { ...newPackage, idPosiljke: newIdPosiljke, idKorisnika: newIdKorisnika, idNarudzbe: newIdNarudzbe }];
        setCurrentPackages(updatedPackages);
        setFilteredPackages(updatedPackages);
        localStorage.setItem('packages', JSON.stringify(updatedPackages));
        setShowForm(false);
        setNewPackage({
            datumDostave: '',
            vrijemeDostave: '',
            adresaDostave: '',
            gradDostave:'',
            status: ''
        });
    };

    const handleDeletePackage = (idPosiljke) => {
        const updatedPackages = currentPackages.filter((item) => item.idPosiljke !== idPosiljke);
        setCurrentPackages(updatedPackages);
        setFilteredPackages(updatedPackages);
        localStorage.setItem('packages', JSON.stringify(updatedPackages));
    };

    const handleUpdatePackage = (e) => {
        e.preventDefault();
        const updatedPackages = currentPackages.map((item) =>
            item.idPosiljke === editPackage.idPosiljke ? editPackage : item
        );
        setCurrentPackages(updatedPackages);
        setFilteredPackages(updatedPackages);
        localStorage.setItem('packages', JSON.stringify(updatedPackages));
        setEditPackage(null);
    };

    const indexOfLastPackage = currentPage * packagesPerPage;
    const indexOfFirstPackage = indexOfLastPackage - packagesPerPage;
    const currentPackagesPerPage = filteredPackages.slice(indexOfFirstPackage, indexOfLastPackage);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <>
            <div className={`overlay ${showForm || editPackage ? 'show' : ''}`}></div>
            <div className="package-page">
                <div className='search'>
                    <input
                        className='searchInput'
                        type="text"
                        placeholder="Status pošiljke"
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                    />
                    <input
                        className='searchInput'
                        type="text"
                        placeholder="Id pošiljke"
                        value={idPosiljke}
                        onChange={(e) => setIdPosiljke(e.target.value)}
                    />
                    <input
                        className='searchInput'
                        type="text"
                        placeholder="Id korisnika"
                        value={idKorisnika}
                        onChange={(e) => setIdKorisnika(e.target.value)}
                    />
                    <input
                        className='searchInput'
                        type="text"
                        placeholder="Id narudzbe"
                        value={idNarudzbe}
                        onChange={(e) => setIdNarudzbe(e.target.value)}
                    />
                    <button className='searchButton' onClick={handleSearch}>Traži</button>
                </div>
                <table className="packagesTable0">
                    <thead>
                        <tr>
                            <th>Id pošiljke</th>
                            <th>Id korisnika</th>
                            <th>Id narudžbe</th>
                            <th>Datum dostave</th>
                            <th>Vrijeme dostave</th>
                            <th>Adresa dostave</th>
                            <th>Grad dostave</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentPackagesPerPage.map((Package, index) => (
                            <tr key={index} style={{ backgroundColor: index % 2 === 0 ? 'rgba(242, 242, 242, 0.5)' : 'rgba(255, 255, 255, 0.5)' }}>
                                <td>{Package.idPosiljke}</td>
                                <td>{Package.idKorisnika}</td>
                                <td>{Package.idNarudzbe}</td>
                                <td>{Package.datumDostave}</td>
                                <td>{Package.vrijemeDostave} h</td>
                                <td>{Package.adresaDostave}</td>
                                <td>{Package.gradDostave}</td>
                                <td>{Package.status}</td>
                                <td>
                                    <button className="btn3" onClick={() => handleEditPackage(Package)}><FaEdit /></button>
                                    <button className="btn3" onClick={() => handleDeletePackage(Package.idPosiljke)}><RiDeleteBin6Line /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div className="pagination">
                    {[...Array(Math.ceil(filteredPackages.length / packagesPerPage)).keys()].map((number) => (
                        <button key={number + 1} onClick={() => paginate(number + 1)} className="btn">
                            {number + 1}
                        </button>
                    ))}
                    <button className="btn2" onClick={() => setShowForm(true)}>Dodaj pošiljku</button>
                </div>
            </div>

            {showForm && (
                <div className="popupForm">
                    <form onSubmit={handleAddPackage}>
                        <h2>Dodaj Pošiljku</h2>
                        <label>
                            Datum dostave:
                            <input
                                type="date"
                                name="datumDostave"
                                value={newPackage.datumDostave}
                                onChange={(e) => setNewPackage({ ...newPackage, datumDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Vrijeme dostave:
                            <input
                                type="time"
                                name="vrijemeDostave"
                                value={newPackage.vrijemeDostave}
                                onChange={(e) => setNewPackage({ ...newPackage, vrijemeDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Adresa dostave:
                            <input
                                type="text"
                                name="adresaDostave"
                                value={newPackage.adresaDostave}
                                onChange={(e) => setNewPackage({ ...newPackage, adresaDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Grad dostave:
                            <input
                                type="text"
                                name="gradDostave"
                                value={newPackage.gradDostave}
                                onChange={(e) => setNewPackage({ ...newPackage, gradDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Status:
                            <input
                                type="text"
                                name="status"
                                value={newPackage.status}
                                onChange={(e) => setNewPackage({ ...newPackage, status: e.target.value })}
                                required
                            />
                        </label>
                        <button type="submit">Dodaj</button>
                        <button type="button" onClick={() => setShowForm(false)}>Zatvori</button>
                    </form>
                </div>
            )}

            {editPackage && (
                <div className="popupForm" style={{ height: "43vh" }} >
                    <form onSubmit={handleUpdatePackage}>
                        <h2>Uredi Pošiljku</h2>
                        <label>
                            Id pošiljke:
                            <input
                                type="text"
                                name="idPosiljke"
                                value={editPackage.idPosiljke}
                                onChange={(e) => setEditPackage({ ...editPackage, idPosiljke: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Id korisnika:
                            <input
                                type="text"
                                name="idKorisnika"
                                value={editPackage.idKorisnika}
                                onChange={(e) => setEditPackage({ ...editPackage, idKorisnika: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Id narudžbe:
                            <input
                                type="text"
                                name="idNarudzbe"
                                value={editPackage.idNarudzbe}
                                onChange={(e) => setEditPackage({ ...editPackage, idNarudzbe: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Datum dostave:
                            <input
                                type="text"
                                name="datumDostave"
                                value={editPackage.datumDostave}
                                onChange={(e) => setEditPackage({ ...editPackage, datumDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Vrijeme dostave:
                            <input
                                type="text"
                                name="vrijemeDostave"
                                value={editPackage.vrijemeDostave}
                                onChange={(e) => setEditPackage({ ...editPackage, vrijemeDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Adresa dostave:
                            <input
                                type="text"
                                name="adresaDostave"
                                value={editPackage.adresaDostave}
                                onChange={(e) => setEditPackage({ ...editPackage, adresaDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Grad dostave:
                            <input
                                type="text"
                                name="gradDostave"
                                value={editPackage.gradDostave}
                                onChange={(e) => setEditPackage({ ...editPackage, gradDostave: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Status:
                            <input
                                type="text"
                                name="status"
                                value={editPackage.status}
                                onChange={(e) => setEditPackage({ ...editPackage, status: e.target.value })}
                                required
                            />
                        </label>
                        <button type="submit">Spremi</button>
                        <button type="button" onClick={() => setEditPackage(null)}>Odustani</button>
                    </form>
                </div>
            )}

        </>
    );
}

export default Table;
