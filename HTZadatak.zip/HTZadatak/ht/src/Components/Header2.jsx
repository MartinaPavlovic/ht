import '../Pages/Packagepage.css'

function Header() {
    return (
        <div className="header2"> 
        </div>
    );
}

export default Header;